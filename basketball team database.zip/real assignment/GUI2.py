

from tkinter import *



def displayDialog(window, team_list):
    window2 = Toplevel(window)
    window2.geometry("1800x650")
    window2.title("")
    window2.config(bg="#1E1E2F")
    teamList = team_list





#============================================================
# Event Handling Methods

    def displayAll():

        for i in range(0, len(teamList)):
            line="Name \t\tCity \t\t Owner \t\tNetworth \t\tShootingGuard \t\tSmallForward \t\tPointGuard \t\tPowerForward \t\tCenter"
            line+='\n'+teamList[i][0]
            line+= '\t'+teamList[i][1]
            line+= '\t\t'+str(teamList[i][2])
            line += "\t\t" +str(teamList[i][3])
            line += "\t\t" +str(teamList[i][4])
            line += '\t\t' +teamList[i][5]
            line += '\t\t' + teamList[i][6]
            line += '\t\t' +teamList[i][7]
            line += '\t\t' + teamList[i][8]
            NBAFinal = teamList[i][9]
            if (NBAFinal==True):
                line += '\t\t\tWon NBA Finals'


            line += '\n\n'
            text.insert(END, line)




    def closeEvent():
        window2.destroy()

    button6 = Button(window2, text="Close", fg="Black", bg ="#FFD700", font=("arial", 12, "bold"), command=closeEvent)
    button6.place(x=10, y=10)


    text = Text(window2, undo=True, height=34, width=300)
    text.place(x=20, y=60)

    displayAll()














