
import sqlite3
from tkinter import *
from tkinter import ttk

from GUI2 import *

#################################
##### Window Set Up #############
window = Tk()
window.title("NBA Teams Database")
window.geometry("1000x600")
window.config(bg="#1E1E2F")


#################################
##### Display Methods #############
def displayChange():
    global current

    display(current)


def display(index):

    global current
    global product

    cur.execute("select * from BasketBallTeam")
    currentTeam=cur.fetchall()[index]
    current = index
    entry2.delete(0, END)
    entry2.insert(END, currentTeam[0])
    entry3.delete(0, END)
    entry3.insert(END, currentTeam[1])
    entry4.delete(0, END)
    entry4.insert(END, currentTeam[2])
    entry5a.delete(0, END)
    entry5a.insert(END, currentTeam[3])
    entry5.delete(0, END)
    entry5.insert(END, currentTeam[4])
    entry6.delete(0, END)
    entry6.insert(END, currentTeam[5])
    entry7.delete(0, END)
    entry7.insert(END, currentTeam[6])
    entry8.delete(0, END)
    entry8.insert(END, currentTeam[7])
    entry9.delete(0, END)
    entry9.insert(END, currentTeam[8])

    WinNBAFinals = currentTeam[9]
    if (WinNBAFinals==True):
        var_cb1.set(1)
    else:
        var_cb1.set(0)

def display2(index):
    global current2
    global allMatches


    current2 = index
    currentMatch = allMatches[index]



    current2 = index
    entry10.delete(0, END)
    entry10.insert(END, currentMatch[0])
    entry12.delete(0, END)
    entry12.insert(END, currentMatch[1])
    entry13.delete(0, END)
    entry13.insert(END, currentMatch[2])
    entry14.delete(0, END)
    entry14.insert(END, currentMatch[3])
    entry15.delete(0, END)
    entry15.insert(END, currentMatch[4])
    entry16.delete(0, END)
    entry16.insert(END, currentMatch[5])







#################################
##### Table Set ups #############
###### Table 1 ##################
con = sqlite3.connect("Basketball.db")
cur = con.cursor()
try:

    cur.execute("""
        CREATE TABLE IF NOT EXISTS BasketBallTeam(
            Name TEXT UNIQUE,
            City TEXT UNIQUE,
            Owner TEXT UNIQUE,
            Networth INT UNIQUE,
            ShootingGuard TEXT UNIQUE,
            SmallForward TEXT UNIQUE,
            PointGuard TEXT UNIQUE,
            PowerForward TEXT UNIQUE,
            Center TEXT UNIQUE,
            WinNBAFinals BOOLEAN
        )
    """)
    data = [
        ("San Antonio Spurs", "San Antonio ","Holt family", 3800000000, "Stephon Castle", "Devin Vassell", "De'Aaron Fox", "Harrison Barnes","Victor Wembanyama",False),
        ("Boston Celtics", "Boston ", "Bill Chisholm", 6000000000, "Payton Pritchard", "Jaylen Brown","Derrick White", "Sam Hauser", "Neemias Queta", True),
        ("Chicago Bulls", "Chicago ", "Jerry Reinsdorf", 5800000000, "Coby White ", "Isaac Okoro ","Josh Giddey", "Matas Buzelis", "Nikola Vucevic", False),
        ("Oklahoma City Thunder ", "Oklahoma City ", "Clay Bennett", 3500000000, "Luguentz Dort", "Jalen Williams ","Shai Gilgeous-Alexander", "Chet Holmgren", "Isaiah Hartenstein", True),
        ("Los Angeles Lakers ", "Los Angeles ", "Mark Walter", 10000000000, "Austin Reaves", "Rui Hachimura","Luka Doncic", "LeBron James", "Deandre Ayton", False)
         ]

    cur.executemany("INSERT OR IGNORE INTO BasketBallTeam VALUES(?, ?, ?,?,?,?,?,?,?,?)", data)

    con.commit()

except Exception as e:
    print("Team Aready Exists" + e)


###### Table 2 ##################

con2 = sqlite3.connect("Matches.db")
cur1 = con2.cursor()
try:

    cur1.execute("""
        CREATE TABLE IF NOT EXISTS Matches(
            ID INT UNIQUE,
            City TEXT ,
            HomeTeam TEXT ,
            AwayTeam TEXT ,
            ScoreHome INT ,
            ScoreAway INT 
        )
    """)
    data2 = [
        (1,"Chicago", "Chicago Bulls", "Los Angeles Lakers", 80,100),
        (2,"Boston", "Boston Celtics", "San Antonio Spurs", 65,45),
        (3,"San Antonio", "San Antonio Spurs", "Charlotte Hornets", 124,100),

         ]

    cur1.executemany("INSERT OR IGNORE INTO Matches VALUES(?, ?, ?,?,?,?)", data2)

    cur1.execute("SELECT * FROM Matches")
    allMatches = cur1.fetchall()

    con2.commit()

except Exception as e:
    print("Match Aready Exists" + e)



###### Table 3 ##################


con3 = sqlite3.connect("PlayersList.db")
cur3 = con3.cursor()
try:

    cur3.execute("""
        CREATE TABLE IF NOT EXISTS PlayerNames(
            Name TEXT UNIQUE
        )
    """)
    data3 = [
        ("Kareem Abdul-Jabbar*",),
        ("Ray Allen*",),
        ("Giannis Antetokounmpo",),
        ("LaMarcus Aldridge",),
        ("Paul Arizin*",),
        ( "Carmelo Anthony*",),

        ("Charles Barkley*",), ("Kobe Bryant*",), ("Larry Bird*",), ("Walt Bellamy*",),( "Rick Barry*",),( "Jimmy Butler",),

        ("Wilt Chamberlain*",),( "Stephen Curry",), ("Vince Carter*",),( "Mike Conley",), ("Maurice Cheeks*",), ("Tyson Chandler",),

        ("Tim Duncan*",), ("Kevin Durant",), ("Clyde Drexler*",), ("Adrian Dantley*",), ("Anthony Davis",),( "DeMar DeRozan",),

        ("Julius Erving*",), ("Patrick Ewing*",),( "Alex English*",), ("Dale Ellis",), ("Joel Embiid",),( "James Edwards",),

        ("Walt Frazier*",),( "Michael Finley",),( "Larry Foust",), ("World B. Free",),( "Derek Fisher",),( "Derrick Favors",),]

    cur3.executemany("INSERT OR IGNORE INTO PlayerNames VALUES(?)", data3)

    con3.commit()

except Exception as e:
    print("Player Aready Exists" + e)









#################################
##### Custom Methods ############

def NetworthDisplay():
    Networth= NetworthVar.get()
    Net = int(Networth)
    cur.execute("SELECT * FROM BasketballTeam WHERE Networth > ?", (Net,))

    NetworthTeams = cur.fetchall()
    displayDialog(window, NetworthTeams)




def ManagerSettings():

        window3 = Tk()
        window3.title("ManagerSettings")
        window3.geometry("400x300")
        window3.config(bg="#1E1E2F")
        frame3 = Frame(window3, width=400, height=500, bg="#2E2E3E", bd=3, relief=RIDGE)
        frame3.place(x=25, y=80)


        label1 = Label(frame3, text="Match ID", bg="#1E1E2F", fg="white", width=18, font=("arial", 10, "bold"))  #
        label1.grid(row=0, column=0, sticky=W + E, padx=5, pady=3)

        entry1 = Entry(frame3)
        entry1.config(bg="#1E1E2F", fg="white")
        entry1.insert(END, '')
        entry1.grid(row=0, column=1, sticky=W + E, padx=5, pady=3, )



        label2 = Label(frame3, text="Home Team", bg="#1E1E2F", fg="white", width=18, font=("arial", 10, "bold"))  #
        label2.grid(row=1, column=0, sticky=W + E, padx=5, pady=3)

        entry2 = Entry(frame3)
        entry2.config(bg="#1E1E2F", fg="white")
        entry2.insert(END, '')
        entry2.grid(row=1, column=1, sticky=W + E, padx=5, pady=3)



        label3 = Label(frame3, text="Away Team", bg="#1E1E2F", fg="white", width=18, font=("arial", 10, "bold"))  #
        label3.grid(row=2, column=0, sticky=W + E, padx=5, pady=3)

        entry3 = Entry(frame3)
        entry3.config(bg="#1E1E2F", fg="white")
        entry3.insert(END, '')
        entry3.grid(row=2, column=1, sticky=W + E, padx=5, pady=3)



        button_style = {"fg": "#1E1E2F", "bg": "#FFD700", "font": ("Helvetica", 11, "bold"), "bd": 2, "relief": RAISED}


        def deleteMatch2():
            try:
                ID=entry1.get()
                cur1.execute("Delete from Matches where ID = \'" + ID + "\'")
                con.commit()
                print("Match Deleted successfully")
            except:
                print('Match: ', ID, ' does not exist in Database')

        def AddMatch():
            try:
                ID=entry1.get()
                Home = entry2.get()
                Away = entry3.get()
                newMatch= [

                    (ID,"City2", Home, Away,0,0,), ]

                cur1.executemany("INSERT OR IGNORE INTO Matches VALUES(?, ?, ?,?,?,?)", newMatch)
                cur1.execute("select * from Matches")
                allMatches = cur1.fetchall()
                display(len(allMatches) - 1)
                con2.commit()
                print("Match Added successfully")
            except:
                print('Match already exists in Database.')


        button1 = Button(frame3, text="Delete Match", command=deleteMatch2, **button_style)
        button1.grid(row=3, column=0, columnspan=2, sticky=W + E, padx=5, pady=3)
        button2 = Button(frame3, text="Add Match", command=AddMatch, **button_style)
        button2.grid(row=4, column=0, columnspan=2, sticky=W + E, padx=5, pady=3)








def nextCmd():
    global current
    cur.execute("select * from BasketBallTeam")
    allTeams=cur.fetchall()
    if (current<(len(allTeams)-1) ):
        current += 1
        display(current)

def prevCmd():
    global current
    if (current > 0):
        current -= 1
        display(current)





def nextMatch():
    global allMatches
    global current2

    if (current2<(len(allMatches)-1) ):
        current2 += 1
        display2(current2)

def prevMatch():
    global allMatches
    global current2
    if (current2 > 0):
        current2 -= 1
        display2(current2)



#################################
##### Custom Methods 2 ############


def closeCmd():
    exit()



def clearCmd():
    entry2.delete(0, END)
    entry3.delete(0, END)
    entry4.delete(0, END)
    entry5.delete(0, END)
    entry5a.delete(0, END)
    entry6.delete(0, END)
    entry7.delete(0, END)
    entry8.delete(0, END)
    entry9.delete(0, END)

    var_cb1.set(0)

def insertCmd():
    Name=entry2.get()
    City=entry3.get()
    Owner= entry4.get()
    Networth= entry5a.get()
    ShootingGuard= entry5.get()
    SmallForward=entry6.get()
    PointGuard=entry7.get()
    PowerForward=entry8.get()
    Center = entry9.get()
    WinNBAFinals=False
    if  (var_cb1.get()==1):
        WinNBAFinals=True

    newTeam = [

        (Name,City,Owner,Networth,ShootingGuard,SmallForward,PointGuard,PowerForward,Center,WinNBAFinals), ]

    cur.executemany("INSERT OR IGNORE INTO BasketBallTeam VALUES(?, ?, ?,?,?,?,?,?,?,?)", newTeam)
    print("New Team added Successfully")

    cur.execute("select * from BasketBallTeam")
    allTeams=cur.fetchall()
    display(len(allTeams)-1)
    con.commit()



def CalculateWinner():
    score1 = int(entry15.get())
    score2 = int(entry16.get())

    if(score1 > score2):
        entry17.delete(0, END)
        entry17.insert(END, entry13.get())
    elif(score2>score1):
        entry17.delete(0, END)
        entry17.insert(END, entry14.get())
    else:
        entry17.delete(0, END)
        entry17.insert(END,"TIE")



def SearchTeamName():
    Name = entry18.get()

    cur.execute("SELECT * FROM BasketballTeam WHERE Name = ?", (Name,))
    allNames = cur.fetchall()
    displayDialog(window, allNames)






#################################
##### Menu Top Right ############

menu1 = Menu(window, bg="#2E2E3E", fg="#FFD700", tearoff=0)
window.config(menu=menu1)

subm1 = Menu(menu1, bg="#2E2E3E", fg="#FFD700", tearoff=0)
menu1.add_cascade(label="Manager Settings", menu=subm1)
subm1.add_command(label="Match Settings", font=("arial", 11, "bold"), command=ManagerSettings)
subm1.add_command(label="Close", font=("arial", 11, "bold"), command=closeCmd)







#################################
##### ListBox ###################


frame = Frame(window, width=400, height=500, bg="#2E2E3E", bd=3, relief=RIDGE)
frame.place(x=25, y=80)


frame_players = Frame(window, bg="#2E2E3E", bd=3, relief=RIDGE)
frame_players.place(x=650, y=80, width=300, height=500)

label_players = Label(frame_players, text="🏀 NBA Players", bg="#2E2E3E", fg="#FFD700", font=("Helvetica", 14, "bold"))
label_players.pack(pady=5)


listbox_players = Listbox(frame_players, bg="#1E1E2F", fg="white",
                          selectbackground="#FFD700", font=("Arial", 10))
listbox_players.pack(side=LEFT, fill=BOTH, expand=True, padx=5, pady=5)  # fill and expand


scrollbar_players = Scrollbar(frame_players, orient=VERTICAL)
scrollbar_players.pack(side=RIGHT, fill=Y)

listbox_players.config(yscrollcommand=scrollbar_players.set)
scrollbar_players.config(command=listbox_players.yview)


cur3.execute("SELECT Name FROM PlayerNames")
all_players = cur3.fetchall()


for player in all_players:
    listbox_players.insert(END, player[0])



#################################
############## Title ############


label1 = Label(window, text="🏀 NBA Teams", fg="#FFD700", bg="#1E1E2F", font=("Helvetica", 20, "bold"))
label1.place(x=120, y=30)

#################################
##### Entry Boxes and Names #####



label2 = Label(frame, text="Name",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label2.grid(row=0, column=0, sticky=W+E, padx=5, pady=3)

entry2 = Entry(frame)
entry2.config(bg="#1E1E2F",fg = "white")
entry2.insert(END, '0')
entry2.grid(row=0, column=1, sticky=W+E, padx=5, pady=3,)



label3 = Label(frame, text="City",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label3.grid(row=1, column=0, sticky=W+E, padx=5, pady=3)

entry3 = Entry(frame)
entry3.config(bg="#1E1E2F",fg = "white")
entry3.insert(END, '0')
entry3.grid(row=1, column=1, sticky=W+E, padx=5, pady=3)



label4 = Label(frame, text="Owner",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label4.grid(row=2, column=0, sticky=W+E, padx=5, pady=3)

entry4 = Entry(frame)
entry4.config(bg="#1E1E2F",fg = "white")
entry4.insert(END, '0')
entry4.grid(row=2, column=1, sticky=W+E, padx=5, pady=3)



label5a = Label(frame, text="Networth",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label5a.grid(row=3, column=0, sticky=W+E, padx=5, pady=3)

entry5a = Entry(frame)
entry5a.config(bg="#1E1E2F",fg = "white")
entry5a.insert(END, '0')
entry5a.grid(row=3, column=1, sticky=W+E, padx=5, pady=3)



label5 = Label(frame, text="Shooting Guard",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label5.grid(row=4, column=0, sticky=W+E, padx=5, pady=3)

entry5 = Entry(frame)
entry5.config(bg="#1E1E2F",fg = "white")
entry5.insert(END, '0')
entry5.grid(row=4, column=1, sticky=W+E, padx=5, pady=3)



label6 = Label(frame, text="Small Forward",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label6.grid(row=5, column=0, sticky=W+E, padx=5, pady=3)

entry6 = Entry(frame)
entry6.config(bg="#1E1E2F",fg = "white")
entry6.insert(END, '0')
entry6.grid(row=5, column=1, sticky=W+E, padx=5, pady=3)



label7= Label(frame, text="Point Guard",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label7.grid(row=6, column=0, sticky=W+E, padx=5, pady=3)

entry7 = Entry(frame)
entry7.config(bg="#1E1E2F",fg = "white")
entry7.insert(END, '0')
entry7.grid(row=6, column=1, sticky=W+E, padx=5, pady=3)



label8= Label(frame, text="Power Forward",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label8.grid(row=7, column=0, sticky=W+E, padx=5, pady=3)

entry8 = Entry(frame)
entry8.config(bg="#1E1E2F",fg = "white")
entry8.insert(END, '0')
entry8.grid(row=7, column=1, sticky=W+E, padx=5, pady=3)



label9= Label(frame, text="Center",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label9.grid(row=8, column=0, sticky=W+E, padx=5, pady=3)

entry9 = Entry(frame)
entry9.config(bg="#1E1E2F",fg = "white")
entry9.insert(END, '0')
entry9.grid(row=8, column=1, sticky=W+E, padx=5, pady=3)



#################################
##### Table2 Entry boxes ########

label10 = Label(frame, text="Match ID",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label10.grid(row=0, column=4, sticky=W+E, padx=5, pady=3)

entry10 = Entry(frame)
entry10.config(bg="#1E1E2F",fg = "white")
entry10.insert(END, '0')
entry10.grid(row=0, column=5, sticky=W+E, padx=5, pady=3,)



label12 = Label(frame, text="City",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label12.grid(row=1, column=4, sticky=W+E, padx=5, pady=3)

entry12 = Entry(frame)
entry12.config(bg="#1E1E2F",fg = "white")
entry12.insert(END, '0')
entry12.grid(row=1, column=5, sticky=W+E, padx=5, pady=3)



label13 = Label(frame, text="Home Team",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label13.grid(row=2, column=4, sticky=W+E, padx=5, pady=3)

entry13 = Entry(frame)
entry13.config(bg="#1E1E2F",fg = "white")
entry13.insert(END, '0')
entry13.grid(row=2, column=5, sticky=W+E, padx=5, pady=3)



label14 = Label(frame, text="Away Team",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label14.grid(row=3, column=4, sticky=W+E, padx=5, pady=3)

entry14 = Entry(frame)
entry14.config(bg="#1E1E2F",fg = "white")
entry14.insert(END, '0')
entry14.grid(row=3, column=5, sticky=W+E, padx=5, pady=3)



label15 = Label(frame, text="ScoreHome",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label15.grid(row=4, column=4, sticky=W+E, padx=5, pady=3)

entry15 = Entry(frame)
entry15.config(bg="#1E1E2F",fg = "white")
entry15.insert(END, '0')
entry15.grid(row=4, column=5, sticky=W+E, padx=5, pady=3)



label16 = Label(frame, text="ScoreAway",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label16.grid(row=5, column=4, sticky=W+E, padx=5, pady=3)

entry16 = Entry(frame)
entry16.config(bg="#1E1E2F",fg = "white")
entry16.insert(END, '0')
entry16.grid(row=5, column=5, sticky=W+E, padx=5, pady=3)



label17 = Label(frame, text="Winner",bg="#1E1E2F", fg="white",width=18, font=("arial", 10, "bold"))   #
label17.grid(row=7, column=4, sticky=W+E, padx=5, pady=3)

entry17 = Entry(frame)
entry17.insert(END, '')
entry17.grid(row=7, column=5, columnspan=1, sticky=W+E,)


#################################
##### Check Box #################

var_cb1 = IntVar()
cb1 = Checkbutton(frame, text="🏆 Won NBA Finals in last 3 years", variable=var_cb1, bg="#2E2E3E", fg="#FFD700", font=("Helvetica", 10, "bold"), activebackground="#2E2E3E", activeforeground="#FFD700")
cb1.grid(row=9, column=0, columnspan=2, pady=5)



#################################
##### Buttons ###################

button_style = {"fg": "#1E1E2F", "bg": "#FFD700", "font": ("Helvetica", 11, "bold"), "bd": 2, "relief": RAISED}

button5 = Button(frame, text="Next",   command=nextCmd,**button_style)
button5.grid(row=11, column=0, sticky=W+E,padx=5, pady=3)


button6 = Button(frame, text="Prev",  command=prevCmd,**button_style)
button6.grid(row=11, column=1, sticky=W+E,padx=5, pady=3)


button7= Button(frame, text="AddNewTeam",  command=insertCmd,**button_style)
button7.grid(row=12, column=1, sticky=W+E,padx=5, pady=3)


button8 = Button(frame, text="Clear", command=clearCmd,**button_style)
button8.grid(row=12, column=0, sticky=W+E,padx=5, pady=3)



cur.execute("select * from BasketBallTeam")
allTeams = cur.fetchall()
button9 = Button(frame, text="Display All Teams", command=lambda : displayDialog(window, allTeams),**button_style)
button9.grid(row=17, column=0, columnspan=1, sticky=W+E,padx=5, pady=3)


button10 = Button(frame, text="Display By Networth", command=NetworthDisplay,**button_style)
button10.grid(row=18, column=0, columnspan=1, sticky=W+E,padx=5, pady=3)

NetworthVar = StringVar()
list1=[7000000000,3000000000,1000000000]
combo12= OptionMenu(frame, NetworthVar, *list1)
combo12.config(bg ="#FFD700" )
NetworthVar.set(1000000000)
combo12.grid(row=18,column=1, sticky=W+E,padx=5, pady=3,)


button11 = Button(frame, text="Next",   command=nextMatch,**button_style)
button11.grid(row=11, column=4, sticky=W+E,padx=5, pady=3)


button12 = Button(frame, text="Prev",  command=prevMatch,**button_style)
button12.grid(row=11, column=5, sticky=W+E,padx=5, pady=3)


button13 = Button(frame, text="Calculate Winner",   command=CalculateWinner,**button_style)
button13.grid(row=12, column=4,columnspan=2, sticky=W+E,padx=5, pady=3)


button14 = Button(frame, text="Search By TeamName", command=SearchTeamName,**button_style)
button14.grid(row=18, column=4, columnspan=1, sticky=W+E,padx=5, pady=3)

entry18 = Entry(frame)
entry18.insert(END, '')
entry18.grid(row=18, column=5, columnspan=1, sticky=W+E,padx=5, pady=3)



display(0)
display2(0)








mainloop()




